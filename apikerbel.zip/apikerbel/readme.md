# Apikerbel Plugin

# Introdução

O **Apikerbel** é um plugin para WordPress que exibe frases aleatórias em diferentes idiomas. Ele permite que os usuários interajam com um botão para gerar frases aleatórias em **Português, Inglês e Espanhol**.

**Versão:** 1.2  
**Autor:** Isabel Andrade  
**Site Oficial:** [Apikerbel.com](https://apikerbel.com)  
**Licença:** GPL2  

## Requisitos

- **WordPress** 5.0 ou superior
- **PHP** 7.4 ou superior

## Metadados do Plugin
```php
/*
Plugin Name: Apikerbel
Plugin URI: https://apikerbel.com
Description: Este é um plugin personalizado para exibir uma mensagem na página.
Version: 1.2
Author: Isabel Andrade
Author URI: https://apikerbel.com
License: GPL2
*/
```

## Funcionalidades
- Exibe frases aleatórias da música "Segure o Tchan" em três idiomas.
- Adiciona um **shortcode** `[apikerbel_lyrics lang="en"]` para exibir frases dinâmicas.
- Cria botões de escolha de idioma com `[botoes_apikerbel]`.
- Inclui um menu no **painel administrativo** do WordPress.
- Usa **CSS externo** (`style.css`) para estilização.

---

## Código Explicado

### 1. Adicionando CSS ao Plugin
```php
function apikerbel_enqueue_styles() {
    wp_enqueue_style('apikerbel-style', plugin_dir_url(__FILE__) . 'style.css');
}
add_action('wp_enqueue_scripts', 'apikerbel_enqueue_styles');
```
- Carrega o arquivo `style.css` para estilizar os elementos do plugin.

### 2. Definição das Letras das Músicas, de acordo com o idioma
```php
$global_lyrics = [
    'pto' => "Pau que nasce torto nunca se endireita...",
    'en' => "A crooked stick never straightens out...",
    'es' => "Un palo que nace torcido nunca se endereza..."
];
```
- Contém as letras da música em três idiomas.

### 3. Função para Obter uma Frase Aleatória de acordo com o idioma selecionado
```php
function apiki_get_random_lyrics($lang) {
    global $global_lyrics;
    if (!isset($global_lyrics[$lang])) return "Idioma não encontrado.";
    $lyrics = explode("\n", $global_lyrics[$lang]);
    return $lyrics[mt_rand(0, count($lyrics) - 1)];
}
```
- Seleciona uma frase aleatória da lista de letras de acordo com o idioma que é passado como parâmetro da função.

### 4. Criando um Shortcode para Exibir Letras Aleatórias
```php
function apiki_shortcode($atts) {
    $lang = isset($atts['lang']) ? $atts['lang'] : 'pto';
    return apiki_get_random_lyrics($lang);
}
add_shortcode('apikerbel_lyrics', 'apiki_shortcode');
```
- Permite a exibição das frases aleatórias em posts e páginas usando `[apikerbel_lyrics lang="en"]`.

### 5. Criando os Botões de Escolha de Idioma
```php
function apiki_buttons_shortcode() {
    ob_start();
    ?>
    <div class="apikerbel-container">
        <form method="post" class="apikerbel-buttons">
            <button type="submit" name="pto">Português</button>
            <button type="submit" name="en">Inglês</button>
            <button type="submit" name="es">Espanhol</button>
        </form>
        <div style="margin-top: 20px; font-size: 20px;">
            <?php
            if (isset($_POST['pto'])) echo "<p><strong>" . apiki_get_random_lyrics('pto') . "</strong></p>";
            if (isset($_POST['en'])) echo "<p><strong>" . apiki_get_random_lyrics('en') . "</strong></p>";
            if (isset($_POST['es'])) echo "<p><strong>" . apiki_get_random_lyrics('es') . "</strong></p>";
            ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('botoes_apikerbel', 'apiki_buttons_shortcode');
```
- Adiciona botões que permitem selecionar um idioma e exibir frases aleatórias, de acordo com o idioma escolhido.
- Criado com o shortcode `[botoes_apikerbel]`.

### 6. Criando um Menu no Admin do WordPress
```php
function apiki_add_admin_menu() {
    add_menu_page(
        'Apikerbel Plugin',
        'Apikerbel',
        'manage_options',
        'apikerbel',
        'apiki_admin_page',
        'dashicons-translation',
        6
    );
}
add_action('admin_menu', 'apiki_add_admin_menu');
```
- Adiciona um menu no painel administrativo chamado **Apikerbel**.
- Usa o ícone `dashicons-translation`.

### 7. Criando a Página de Admin
```php
function apiki_admin_page() {
    ?>
    <div class="wrap">
        <h1>Apikerbel - Frases Aleatórias</h1>
        <form method="post">
            <button type="submit" name="pto" class="button button-primary">Mostrar Frase em Português</button>
            <button type="submit" name="en" class="button">Mostrar Frase em Inglês</button>
            <button type="submit" name="es" class="button">Mostrar Frase em Espanhol</button>
        </form>
        <div style="margin-top: 20px; font-size: 20px;">
            <?php
            if (isset($_POST['pto'])) echo "<p><strong>" . apiki_get_random_lyrics('pto') . "</strong></p>";
            if (isset($_POST['en'])) echo "<p><strong>" . apiki_get_random_lyrics('en') . "</strong></p>";
            if (isset($_POST['es'])) echo "<p><strong>" . apiki_get_random_lyrics('es') . "</strong></p>";
            ?>
        </div>
    </div>
    <?php
}
```
- Cria uma interface administrativa para exibir frases aleatórias no local desejado.

---

# Hooks e Filtros

## Shortcodes Disponíveis

- `[botoes_apikerbel]` → Exibe os botões para escolha de idioma.

## Ações (Actions)

- `add_action('wp_enqueue_scripts', 'apikerbel_enqueue_styles');` → Adiciona o CSS do plugin.
- `add_action('admin_menu', 'apiki_add_admin_menu');` → Adiciona o menu no painel admin.

---

# Instalação

## Instalação via Painel do WordPress

1. No painel do WordPress, acesse **Plugins > Adicionar Novo**.
2. Clique em **Enviar Plugin** e selecione o arquivo `apikerbel.zip`.
3. Clique em **Instalar Agora** e, após a instalação, **ative o plugin**.
4. Na página escolhida para exibir o plugin, adicione o seguinte shortcode: `[botoes_apikerbel]`, e clique em visualizar.

---

# FAQ

### O plugin não aparece no menu do WordPress. O que fazer?
- Verifique se o plugin está ativado e se sua versão do WordPress é compatível.

### Como posso personalizar o design?
- Adicione **CSS personalizado** ao seu tema ou edite o arquivo `style.css` dentro da pasta do plugin.

---

# Suporte
Para relatar problemas ou sugerir melhorias, entre em contato pelo site: [https://apikerbel.com](https://apikerbel.com).
