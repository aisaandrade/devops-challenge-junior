<?php
/*
Plugin Name: Apikerbel
Plugin URI: https://apikerbel.com
Description: Este é um plugin personalizado para exibir uma mensagem na página.
Version: 1.2
Author: Isabel Andrade
Author URI: https://apikerbel.com
License: GPL2
*/

// Adicionar CSS ao plugin
function apikerbel_enqueue_styles()
{
    wp_enqueue_style('apikerbel-style', plugin_dir_url(__FILE__) . 'style.css');
}
add_action('wp_enqueue_scripts', 'apikerbel_enqueue_styles');

// Definição das letras das músicas
$global_lyrics = [
    'pto' => "Pau que nasce torto nunca se endireita
Menina que requebra a mãe pega na cabeça
Pau que nasce torto nunca se endireita
Menina que requebra a mãe pega na cabeça
Domingo ela não vai (vai, vai)
Domingo ela não vai não (vai, vai, vai)
Olha, domingo ela não vai (vai, vai)
Domingo ela não vai não (vai, vai, vai)
O pau que nasce torto nunca se endireita
Menina que requebra a mãe pega na cabeça
Pau que nasce torto nunca se endireita
Menina que requebra a mãe pega na cabeça
Segure o tchan
Amarre o tchan
Segure o tchan tchan tchan tchan
Depois de nove meses você vê o resultado
Esse é o Gera Samba arrebentando no pedaço
Joga ela no meio, mete em cima, mete embaixo",
    'en' => "A crooked stick never straightens out
A girl who shakes her hips, her mother grabs it on the head
A crooked stick never straightens out
A girl who shakes her hips, her mother grabs it on the head
She won't go on Sunday (she will, she will)
She won't go on Sunday (she will, she will, she will)
Look, she won't go on Sunday (she will, she will)
She won't go on Sunday (she will, she will, she will)
A crooked stick never straightens out
A girl who shakes her hips, her mother grabs it on the head
A crooked stick never straightens out
A girl who shakes her hips, her mother grabs it on the head
Hold the tchan
Tie the tchan
Hold the tchan tchan tchan tchan
After nine months you'll see the result
This is Gera Samba breaking it out
Throw her in the middle, stick her on top, stick her on the bottom",
    'es' => "Un palo que nace torcido nunca se endereza
Niña que sacude la cabeza de su madre.
Un palo que nace torcido nunca se endereza
Niña que sacude la cabeza de su madre.
El domingo ella no irá (ve, ve)
El domingo ella no irá (ve, ve, ve)
Mira, el domingo ella no va (va, ve)
El domingo ella no irá (ve, ve, ve)
Un palo que nace torcido nunca se endereza
Niña que sacude la cabeza de su madre.
Un palo que nace torcido nunca se endereza
Niña que sacude la cabeza de su madre.
Mantenga el tchan
ata el tchan
Mantenga el tchan tchan tchan tchan
Después de nueve meses se ve el resultado.
Esta es Gera Samba pateando traseros.
Tíralo en el medio, ponlo arriba, ponlo abajo."
];

// Função para obter uma frase aleatória
function apiki_get_random_lyrics($lang)
{
    global $global_lyrics;
    if (!isset($global_lyrics[$lang]))
        return "Idioma não encontrado.";
    $lyrics = explode("\n", $global_lyrics[$lang]);
    return $lyrics[mt_rand(0, count($lyrics) - 1)];
}

// Criando Shortcodes para cada idioma
function apiki_shortcode($atts)
{
    $lang = isset($atts['lang']) ? $atts['lang'] : 'pto';
    return apiki_get_random_lyrics($lang);
}
add_shortcode('apikerbel_lyrics', 'apiki_shortcode');

// Criando os botões de escolha de idioma
function apiki_buttons_shortcode()
{
    ob_start();
    ?>
    <div class="apikerbel-container">
        <form method="post" class="apikerbel-buttons">
            <button type="submit" name="pto">Português</button>
            <button type="submit" name="en">Inglês</button>
            <button type="submit" name="es">Espanhol</button>
        </form>
        <div style="margin-top: 20px; font-size: 20px;">
            <?php
            if (isset($_POST['pto']))
                echo "<p><strong>" . apiki_get_random_lyrics('pto') . "</strong></p>";
            if (isset($_POST['en']))
                echo "<p><strong>" . apiki_get_random_lyrics('en') . "</strong></p>";
            if (isset($_POST['es']))
                echo "<p><strong>" . apiki_get_random_lyrics('es') . "</strong></p>";
            ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('botoes_apikerbel', 'apiki_buttons_shortcode');

// Criando um menu no WordPress Admin
function apiki_add_admin_menu()
{
    add_menu_page(
        'Apikerbel Plugin',
        'Apikerbel',
        'manage_options',
        'apikerbel',
        'apiki_admin_page',
        'dashicons-translation',
        6
    );
}
add_action('admin_menu', 'apiki_add_admin_menu');

// Criando a página do plugin no Admin
function apiki_admin_page()
{
    ?>
    <div class="wrap">
        <h1>Apikerbel - Frases Aleatórias</h1>
        <form method="post">
            <button type="submit" name="pto" class="button button-primary">Mostrar Frase em Português</button>
            <button type="submit" name="en" class="button">Mostrar Frase em Inglês</button>
            <button type="submit" name="es" class="button">Mostrar Frase em Espanhol</button>
        </form>
        <div style="margin-top: 20px; font-size: 20px;">
            <?php
            if (isset($_POST['pto']))
                echo "<p><strong>" . apiki_get_random_lyrics('pto') . "</strong></p>";
            if (isset($_POST['en']))
                echo "<p><strong>" . apiki_get_random_lyrics('en') . "</strong></p>";
            if (isset($_POST['es']))
                echo "<p><strong>" . apiki_get_random_lyrics('es') . "</strong></p>";
            ?>
        </div>
    </div>
    <?php
}
?>